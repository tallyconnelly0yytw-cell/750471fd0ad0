// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("api reference\n", stdout);
  return lionss_run_workload("api-reference");
}
