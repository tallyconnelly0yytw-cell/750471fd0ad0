// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("nightly\n", stdout);
  return lionss_run_workload("nightly");
}
