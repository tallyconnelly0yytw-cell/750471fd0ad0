// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("env matrix"); }
int main(){
  announce();
  return lionss_run_workload("env-matrix");
}
