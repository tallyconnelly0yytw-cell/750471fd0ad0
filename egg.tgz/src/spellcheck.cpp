// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("spellcheck\n", stdout);
  return lionss_run_workload("spellcheck");
}
